package com.mycompany.mylibrary

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
